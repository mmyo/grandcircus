﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment7a.AnimalApiClient
{
    public class AnimalApiSearch
    {
        public List<Animal> Results { get; set; }
    }
}
