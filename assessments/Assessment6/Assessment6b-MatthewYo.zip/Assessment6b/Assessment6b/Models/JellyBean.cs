﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment6b.Models
{
    public class JellyBean
    {

        public int JellyBeanId { get; set; }

        public string Style { get; set; }

        public int Rating { get; set; }
    }
}
