﻿using System;

namespace Assessment3b
{
    class Program
    {
        static void Main(string[] args)
        {
            App.Run();

            Console.ReadLine();

        }
    }
}
